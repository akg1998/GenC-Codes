import java.util.*;
public class StudentMain{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		Student s=new Student();
		s=StudentMain.getStudentDetails();
		/*s1.calculateAvg();
		s1.findGrade();*/
		System.out.println("Id:"+s.getId());
		System.out.println("Name:"+s.getName());
		System.out.printf("Average:%.2f\n",s.getAverage());
		System.out.println("Grade:"+s.getGrade());
	}
	public static Student getStudentDetails(){
		Student s = new Student();
		System.out.println("Enter the id:");
		s.setId(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter the name:");
		s.setName(sc.nextLine());
		System.out.println("Enter the no of subjects:");
		int n;
		n=sc.nextInt();
		while(n<0){
			System.out.println("Invalid number of subject");
			System.out.println("Enter the no of subjects:");
			n=sc.nextInt();
		}
		int[] marks=new int[n];
		for(int i=0;i<n;i++){
			System.out.println("Enter mark for subject "+(i+1));
			marks[i]=sc.nextInt();
			while(marks[i]<0 || marks[i]>100){
				System.out.println("Invalid Mark");
				System.out.println("Enter mark for subject "+(i+1));
				marks[i]=sc.nextInt();
			}
		}
		s.setMarks(marks);
		s=new Student(s.getId(),s.getName(),s.getMarks());
		s.calculateAvg();
		s.findGrade();
		return s;
	}
}