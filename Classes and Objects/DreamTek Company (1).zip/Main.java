import java.util.*;
public class Main{
    public static void main(String[] args){
        Associate as= new Associate();
        Scanner sc;
        sc=new Scanner(System.in);
        System.out.println("Enter the associate id:");
        int a;
        a=sc.nextInt();
        as.setAssociateId(a);
        //a=as.getAssociateId();
       // System.out.println(a);
        System.out.println("Enter the associate name:");
        String name;
        name=sc.next();
        as.setAssociateName(name);
       // name=as.getAssociateName();
        //System.out.println(name);
        System.out.println("Enter the number of days:");
        int id;
        id=sc.nextInt();
        //System.out.println(id);
        as.trackAssociateStatus(id);
        String work=null;
        work=as.getWorkStatus();
        System.out.println("The associate "+name+" work status:"+work);
    }
}