public class Associate{
   
        private int associateId;
        private String associateName=null;
        private String workStatus=null;
        
    public int getAssociateId(){
        return associateId;
    }
    public void setAssociateId(int n){
        associateId=n;        
    }
    public String getAssociateName(){
        return associateName;
    }
    public void setAssociateName(String name){
        associateName=name;
    }
    public String getWorkStatus(){
        return workStatus;
    }
    public void setWorkStatus(String ws){
        workStatus=ws;
    }
    public void trackAssociateStatus(int track){
        if(track>0 && track<=20)
        setWorkStatus("Core skills");
        else if(track>20 && track<=40)
        setWorkStatus("Advanced modules");
        else if(track>40 && track<=60)
        setWorkStatus("Project phase");
        else
        setWorkStatus("Deployed in project");
    }
}