import java.util.*;
public class StudentMain{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int student_id;
		String name,address,choice,college_name;
		System.out.println("Enter Student's Id:");
		student_id=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter Student's Name:");
		name=sc.nextLine();
		System.out.println("Enter Student's address:");
		address=sc.nextLine();
		System.out.println("Whether the student is from NIT(Yes/No):");
		choice=sc.nextLine();
		while(!(choice.equalsIgnoreCase("yes") || choice.equalsIgnoreCase("no"))){
			System.out.println("Wrong Input");
			choice=null;
			choice=sc.nextLine();
			}
		Student s;
		if(choice.equals("no")){
			System.out.println("Enter the college name:");
			college_name=sc.nextLine();
			s=new Student(student_id,name,address,college_name);
		}
		else{
			s=new Student(student_id,name,address);
		}
		System.out.println("Student id:"+s.getStudentId());
		System.out.println("Student name:"+s.getStudentName());
		System.out.println("Address:"+s.getStudentAddress());
		System.out.println("Collge name:"+s.getCollegeName());
	}
}