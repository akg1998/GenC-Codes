import java.util.*;
public class Main{
	public static void main(String[] args){
	//	Scanner sc=new Scanner(System.in);
		Employee e=new Employee();
		e=getEmployeeDetails();
		int percentage=getPFPercentage();
		e.calculateNetSalary(percentage);

		System.out.println("Id: "+e.getEmployeeId());
		System.out.println("Name: "+e.getEmployeeName());
		System.out.println("Salary: "+e.getSalary());
		System.out.println("Net Salary: "+e.getNetSalary());
	}
	public static Employee getEmployeeDetails(){
		 Scanner sc=new Scanner(System.in);
		 Employee e=new Employee();
		System.out.println("Enter Id:");
		e.setEmployeeId(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter Name:");
		e.setEmployeeName(sc.nextLine());
		System.out.println("Enter salary:");
		e.setSalary(sc.nextDouble());
		System.out.println("Enter PF percentage:");
		return e;
	}
	public static int getPFPercentage(){
		Scanner sc=new Scanner(System.in);
		int p;
		p=sc.nextInt();
		return p;
	}
	
	
}