import java.util.*;
public class Main{
	public static void main(String[] args) {
		int noofbookings;
		int totalprice;
		int tickets,ticketid,price,nooftickets;
		Ticket t=new Ticket();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no of bookings:");
		noofbookings=sc.nextInt();
		System.out.println("Enter the available tickets:");
		Ticket.setAvailableTickets(sc.nextInt());
		int i;
		for(i=0;i<noofbookings;i++){
			System.out.println("Enter the ticketid:");
			t.setTicketid(sc.nextInt());
			System.out.println("Enter the price:");
			t.setPrice(sc.nextInt());
			System.out.println("Enter the no of tickets:");
			nooftickets=sc.nextInt();
			System.out.println("Available tickets:"+Ticket.getAvailableTickets());
			System.out.println("Total amount:"+t.calculateTicketCost(nooftickets));
			System.out.println("Available ticket after booking:"+Ticket.getAvailableTickets());
		}
	}
}