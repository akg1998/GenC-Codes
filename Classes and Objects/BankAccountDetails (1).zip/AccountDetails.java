import java.util.*;
public class AccountDetails{
	Scanner sc=new Scanner(System.in);
	int withdraw;
	public static void main(String[] args) {
		AccountDetails c=new AccountDetails();
		int w;
		Account b=new Account();
		b=c.getAccountDetails();
		w=c.getWithdrawAmount();
		boolean x;
		x=b.withdraw(w); 
	}
	public Account getAccountDetails(){
		Account a=new Account();
		int balance;
		System.out.println("Enter account id:");
		a.setAccountId(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter account type:");
		a.setAccountType(sc.nextLine());
		System.out.println("Enter balance:");
		balance=sc.nextInt();
		a.setBalance(balance);
		sc.nextLine();
		while(balance<=0){
			System.out.println("Balance should be positive");
			System.out.println("Enter balance:");
			balance=sc.nextInt();
			sc.nextLine();
			a.setBalance(balance);
		}
		return a;
	}
	public int getWithdrawAmount(){
		System.out.println("Enter amount to be withdrawn:");
		withdraw=sc.nextInt();
		while(withdraw<=0){
			System.out.println("Amount should be positive");
			System.out.println("Enter amount to be withdrawn:");
			withdraw=sc.nextInt();
			sc.nextLine();
		}
		return withdraw;
	}
}