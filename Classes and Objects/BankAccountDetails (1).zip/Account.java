public class Account{
	private int accountId;
	private String accountType;
	private int balance;
	int x;
	//AccountDetails a=new AccountDetails();
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public boolean withdraw(int bal){
	//	Account b=new Account();
		//x=a.getWithdrawAmount();
		if(getBalance()<bal){
			System.out.println("Sorry!!! No enough balance");
			return false;
		}
		else{
			setBalance(getBalance()-bal);
			System.out.println("Balance amount after withdraw: "+getBalance());
			return true;
			
		}
	}
}