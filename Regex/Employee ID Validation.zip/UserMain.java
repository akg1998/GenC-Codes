import java.util.*;
public class UserMain{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String valid=null;
		System.out.println("Enter your ID");
		valid=sc.nextLine();
		if(!(valid.matches("[GBL]{3}[//0-9]{4}[//0-9]{5}"))){
			System.out.println("Incorrect ID");
			return;
		}
		System.out.println("Login Success");
	}
}