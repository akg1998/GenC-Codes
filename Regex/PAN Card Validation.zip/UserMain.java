import java.util.*;
public class UserMain{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String pan=null;
		System.out.println("Enter your PAN number");
		pan=sc.nextLine();
		if(!(pan.matches("^[A-Z]{5}[0-9]{4}[A-Z]{1}"))){
			System.out.println("Invalid PAN number");
			return;
		}
		System.out.println("Valid PAN number");
	
	}
}