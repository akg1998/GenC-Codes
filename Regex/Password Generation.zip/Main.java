import java.util.*;
public class Main{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String password=null;
		System.out.println("Generate your Security Code");
		password=sc.nextLine();
		if(!(password.matches("^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@*#])[A-Za-z\\d@*#]{8,}$"))){
			System.out.println("Invalid Security Code, Try Again!");
			return;
		}
		System.out.println("Security Code Generated Successfully");
	}
}

///"[\\w@#*]*{8,}$"