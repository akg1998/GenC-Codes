import java.util.*;
public class Main{
	static Scanner sc=new Scanner(System.in);
	static Hosteller s=new Hosteller();
	public static void main(String[] args) {
		System.out.println("Enter the Details:");
		System.out.println("Student Id");
		s.setStudentId(sc.nextInt());
		sc.nextLine();
		System.out.println("Student Name");
		s.setName(sc.nextLine());
		System.out.println("Department Id");
		s.setDepartmentId(sc.nextInt());
		sc.nextLine();
		System.out.println("Gender");
		s.setGender(sc.nextLine());
		System.out.println("Phone Number");
		s.setPhone(sc.nextLine());
		System.out.println("Hostel Name");
		s.setHostelName(sc.nextLine());
		System.out.println("Room Number");
		s.setRoomNumber(sc.nextInt());
		sc.nextLine();
		Main.getHostellerDetails();
		System.out.println("The Student Details");
		System.out.println(s.getStudentId()+" "+s.getName()+" "+s.getDepartmentId()+" "+s.getGender()+" "+s.getPhone()+" "+s.getHostelName()+" "+s.getRoomNumber());
	}
	public static Hosteller getHostellerDetails(){
		char choice1,choice2;
		System.out.println("Modify Room Number(Y/N)");
		choice1=sc.next().charAt(0);
		if(choice1=='Y' || choice1=='y')
		{
			System.out.println("New Room Number");
			s.setRoomNumber(sc.nextInt());
			sc.nextLine();
		}
		System.out.println("Modify Phone Number(Y/N)");
		choice2=sc.next().charAt(0);
		if(choice2=='Y' || choice2=='y')
		{
			System.out.println("New Phone Number");
			s.setPhone(sc.next());
		}
		return null;
		
	}
}