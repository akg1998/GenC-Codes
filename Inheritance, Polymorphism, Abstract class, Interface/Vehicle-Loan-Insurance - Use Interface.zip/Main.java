import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
       Vehicle v=new Vehicle();
       v.issueLoan();
       v.takeInsurance();
    }
}