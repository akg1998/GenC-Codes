public class SavingsAccount extends Account{
	
	private double minimumBalance;
	
	public SavingsAccount(int accountNumber, Customer customerObj, double balance) {
		super(accountNumber, customerObj, balance);
		// TODO Auto-generated constructor stub
	}
	
    public SavingsAccount(int accountNumber, Customer customerObj, double balance, double minimumBalance) {
		super(accountNumber, customerObj, balance);
		this.minimumBalance = minimumBalance;
	}

	//Uncomment the getters and setters after writing the attributes

    
    

	public double getMinimumBalance() {
		return minimumBalance;
	}

	public void setMinimumBalance(double minimumBalance) {
		this.minimumBalance = minimumBalance;
	}

	@Override
	public boolean withdraw(double amount) {
		double bal;
		bal=getBalance()-amount;
		if(bal>minimumBalance){
			setBalance(bal);
			return true;
		}
		return false;
	}
    

    
}

    