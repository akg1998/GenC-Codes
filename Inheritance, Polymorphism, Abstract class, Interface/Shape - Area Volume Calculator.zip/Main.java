import java.util.*;
public class Main
{
    public static void main(String args[])
    {
        Shape[] s=new Shape[5];
        String shape[]=new String[5];
        int i;
        /*double volumet=0.0,volumec=0.0,volumer=0.0,volumes=0.0;
        double areat=0.0,areac=0.0,arear=0.0,areas=0.0;*/
        double area,volume;
        Scanner sc=new Scanner(System.in);
        for(i=0;i<5;i++)
        {
            double l=0.0,b=0.0,h=0.0;
            shape[i]=sc.next();
            if(shape[i].equals("Triangle"))
            {
                Triangle t =new Triangle();
                s[i]=t;
             //   System.out.println("Triangle");
                b=sc.nextDouble();
                h=sc.nextDouble();
                t.setBase(b);
                t.setHeight(h);
               // area=s[i].area();
                //System.out.println("Area "+area);
               // volume=s[i].volume();
              //  System.out.println("Volume "+volume);
            }
            else if(shape[i].equals("Cube"))
            {
                Cube c=new Cube();
                s[i]=c;
              //  System.out.println("Cube");
                l=sc.nextDouble();
                b=sc.nextDouble();
                h=sc.nextDouble();
                c.setLength(l);
                c.setWidth(b);
                c.setHeight(h);
               // area=s[i].area();
               // System.out.println("Area "+area);
               // volume=s[i].volume();
               // System.out.println("Volume "+volume);
            }
            else if(shape[i].equals("Rectangle"))
            {
                Rectangle r=new Rectangle();
                s[i]=r;
               // System.out.println("Rectangle");
                l=sc.nextDouble();
                b=sc.nextDouble();
                r.setLength(l);
                r.setWidth(b);
               // area=s[i].area();
                //System.out.println("Area "+area);
                //volume=s[i].volume();
                //System.out.println("Volume "+volume);
            }
            else if(shape[i].equals("Sphere"))
            {
                Sphere q=new Sphere();
                s[i]=q;
                //System.out.println("Sphere");
                l=sc.nextDouble();
                q.setRadius(l);
                //area=s[i].area();
          //      System.out.println("Area "+area);
                //volume=s[i].volume();
               // System.out.println("Volume "+volume);
            }
        }
        for(i=0;i<5;i++)
        {
            if(shape[i].equals("Triangle")){
                area=s[i].area();
                System.out.println("Area "+area);
                volume=s[i].volume();
            }
            else if(shape[i].equals("Sphere")){
                area=s[i].area();
                System.out.println("Area "+area);
                volume=s[i].volume();
                System.out.println("Volume "+volume);
            }
            else if(shape[i].equals("Rectangle")){
                area=s[i].area();
                System.out.println("Area "+area);
                volume=s[i].volume();
            }
            else if(shape[i].equals("Cube")){
                area=s[i].area();
                System.out.println("Area "+area);
                volume=s[i].volume();
                System.out.println("Volume "+volume);
            }
        }
    }
    
}