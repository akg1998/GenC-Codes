public class Rectangle extends Shape
{
    private double length;
    private double width;
    public void setLength(double l){
        this.length=l;
    }
    public void setWidth(double b){
        this.width=b;
    }
    public double getLength()
    {
        return length;
    }
    public double getWidth(){
        return width;
    }
    public double area(){
        return getLength()*getWidth();
    }
    public double volume(){
        return -1;
    }
    
}