public interface Spatial
{
}