import java.lang.*;
public class Sphere extends Shape implements Spatial
{
    private double radius;
    public void setRadius(double r){
        this.radius=r;
    }
    public double getRadius(){
        return radius;
    }
    public double area(){
        return (4*Math.PI*getRadius()*getRadius());
    }
    public double volume(){
        return ((4*Math.PI*getRadius()*getRadius()*getRadius())/3);
    }
}