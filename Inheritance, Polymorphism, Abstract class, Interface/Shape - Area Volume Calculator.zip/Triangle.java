public class Triangle extends Shape
{
    private double base;
    private double height;
    public void setBase(double b){
        this.base=b;
    }
    public void setHeight(double h){
        this.height=h;
    }
    public double getBase(){
        return base;
    }
    public double getHeight(){
        return height;
    }
    public double area(){
        return(0.5*(getBase()*getHeight()));
    }
    public double volume(){
        return -1;
    }
    
}