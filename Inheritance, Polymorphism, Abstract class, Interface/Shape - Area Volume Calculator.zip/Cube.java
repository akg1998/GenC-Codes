public class Cube extends Shape implements Spatial
{
    private double length;
    private double width;
    private double height;
    public void setLength(double l){
        this.length=l;
    }
    public void setWidth(double w){
        this.width=w;
    }
    public void setHeight(double h){
        this.height=h;
    }
    public double getLength(){
        return length;
    }
    public double getWidth(){
        return width;
    }
    public double getHeight()
    {
        return height;
    }
    public double area(){
        return ((2*getLength()*getWidth())+(2*getLength()*getHeight())+(2*getWidth()*getHeight()));
    }
    public double volume(){
        return (getLength()*getWidth()*getHeight());
    }
}