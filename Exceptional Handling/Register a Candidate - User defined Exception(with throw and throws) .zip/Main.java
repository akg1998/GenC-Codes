import java.util.*;
import java.lang.Exception;
public class Main{
    public static Candidate getCandidateDetails()throws InvalidSalaryException{
        double expectedSalary;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the candidate Details");
        Candidate c=new Candidate();
        System.out.println("Name");
        c.setName(sc.nextLine());
        System.out.println("Gender");
        c.setGender(sc.nextLine());
        System.out.println("Expected Salary");
        expectedSalary=sc.nextDouble();
        c.setExpectedSalary(expectedSalary);
        if(expectedSalary<10000){
            throw new InvalidSalaryException("Registration Failed. Salary cannot be less than 10000.");
        }
        else{
        return c;
        }
    }
    public static void main (String[] args){
       try{
        Candidate c= getCandidateDetails();
        System.out.println("Registration Successful");
       }
        catch(InvalidSalaryException e){
            System.out.println(e.getMessage());
        }
            
    }
}