import java.util.*;
public class Division{
	public String divideTwoNumbers(int number1,int number2){
		int result;
		String x = null;
		try{
				result=number1/number2;
				x="The answer is "+result+". ";
		}
		catch(ArithmeticException a){
			x="Division by zero is not possible.";
		}
		finally{
			 x=x+" Thanks for using the application.";
			 return x;
		}
		
	}
	public static void main(String[] args) {
		String result=null;
		Scanner sc=new Scanner(System.in);
		Division d=new Division();
		int n1,n2;
		System.out.println("Enter the numbers");
		n1=sc.nextInt();
		n2=sc.nextInt();
		result=d.divideTwoNumbers(n1,n2);
		System.out.println(result);
	}
}