import java.util.*;
public class ArrayException{
	public String getPriceDetails(){
		Scanner sc=new Scanner(System.in);
		int number;
		String msg;
		System.out.println("Enter the number of elements in the array");
		number=sc.nextInt();
		System.out.println("Enter the price details");
		int price[]=new int[number];
		int i;
		for(i=0;i<number;i++){
			try{
				price[i]=sc.nextInt();
			}
			catch(InputMismatchException w){
				msg="Input was not in the correct format";
				return msg;
			}
			catch(ArrayIndexOutOfBoundsException a)
			{
				msg="Array index is out of range";
				return msg;
			}
		}
		try{
		System.out.println("Enter the index of the array element you want to access");
		int z;
		z=sc.nextInt();
		return "The array element is "+price[z];
		}
		catch(ArrayIndexOutOfBoundsException a){
			msg="Array index is out of range";
			return msg;
		}
	}
	public static void main(String[] args) {
		
		String msg=null;
		ArrayException a=new ArrayException();
		msg=a.getPriceDetails();
		System.out.println(msg);
		
	}
}