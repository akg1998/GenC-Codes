import java.util.*;
import java.text.*;
public class Main {

public static void main(String [] args)throws ParseException {
   
	Scanner sc = new Scanner(System.in);
    Date time_now = new Date();
    SimpleDateFormat ft = new SimpleDateFormat("dd/MM/yyyy HH:mm");
    time_now = ft.parse("29/10/2019 20:10");

    System.out.println("In-time");
    String inTime = sc.nextLine();
    String invalidIn = inTime + " is an Invalid In-Time";

    Date in_Time = new Date();
    
    try{
        in_Time = ft.parse(inTime);
    }catch(ParseException e){
        System.out.println(invalidIn);
        return;
    };
    if(time_now.before(in_Time) || time_now.equals(in_Time)){
        System.out.println(invalidIn);
        return;
    }
    System.out.println("Out-time");
    String outTime = sc.nextLine();
    String invalidOut = outTime + " is an Invalid Out-Time";
    Date out_Time = new Date();
    try{
        out_Time = ft.parse(outTime);
    }catch(ParseException e){
        System.out.println(invalidOut);
        return;
    };
    if(out_Time.before(in_Time) || out_Time.equals(in_Time)){
        System.out.println(invalidOut);
        return;
    }
    long start, end;
    start = in_Time.getTime();
    end = out_Time.getTime();
    long parkingCharge = 0, minutes = 0;
    minutes = (end - start)/60000;
    double hour = (float)minutes/(float)60;
    parkingCharge = 10 * (long)Math.ceil(hour);
    System.out.println(parkingCharge + " Rupees");
    
}
}