import java.util.*;
import java.util.regex.Pattern;
public class ValidateUtility
{
    public static void main(String args[])
    {
    	 Scanner sc = new Scanner(System.in);
         Validate v1 = validateEmployeeName();
         String employeeName=sc.nextLine();
         if(v1.validateName(employeeName)){
             System.out.println("Employee name is valid");
         }
         else{
             System.out.println("Employee name is invalid");
         }
         Validate v2 = validateProductName();
         String productName=sc.nextLine();
         if(v2.validateName(productName)){
             System.out.println("Product name is valid");
         }
         else{
             System.out.println("Product name is invalid");
         }
    }
    
    public static Validate validateEmployeeName() 
    {
    	  Validate v1 = Employeename-> {return Pattern.matches("[a-zA-Z ]{5,20}",Employeename);};
          return v1; 
    }
    
    public static Validate validateProductName() 
    {
    	 Validate v2 = Productname->{return Pattern.matches("[a-zA-Z]{1}[0-9]{5}",Productname);};
         return v2;
    }
}