import java.util.*;
public class Main{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        FlightManagementSystem fms=new FlightManagementSystem();
        Flight f=new Flight(Integer.parseInt(sc.nextLine()),sc.nextLine(),sc.nextLine(),Integer.parseInt(sc.nextLine()),Double.parseDouble(sc.nextLine()));
boolean status = fms.addFlight(f);
        
        if(status)
        {
            System.out.println("Flight details added successfully");
            return;
        }
        System.out.println("Addition not done");
        return;
    
    }
}