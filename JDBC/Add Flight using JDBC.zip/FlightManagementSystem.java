import java.sql.*;
import java.util.*;
public class FlightManagementSystem{
	public boolean addFlight(Flight flightObj){
		try{int flightId,noofseats;
		String source,destination;
		double flightfare;
		DB db=new DB();
		flightId=flightObj.getFlightId();
		noofseats=flightObj.getNoOfSeats();
		source=flightObj.getSource();
		destination=flightObj.getDestination();
		flightfare=flightObj.getFlightFare();
		
		Connection con=db.getConnection();
		Statement st=con.createStatement();
		int rowAffected=st.executeUpdate("Insert into flight "+"(flightId,source,destination,noofseats,flightfare)"+" values "+"('"+flightId+"','"+source+"','"+destination+"','"+noofseats+"','"+flightfare+"')");
		if(rowAffected>0)
			return true;
		}
		catch(Exception e){}
		return false;
		
	}
}