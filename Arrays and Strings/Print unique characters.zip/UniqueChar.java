import java.util.*;
public class UniqueChar{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the sentence:");
		String sent=null;
		int i,flag1=0,j=0,flag2=0,cnt=0;
		sent=sc.nextLine();
		char[] x = null;
		char s[]=sent.toCharArray();
		for(i=0;i<sent.length();i++){
			if((s[i] <= 'a' && s[i] >= 'z') || (s[i] <= 'A' && s[i] >= 'Z')){
				System.out.println("Invalid Sentence");
				return;
			}
			if(s[i]>=48 && s[i]<=57)
			{
				System.out.println("Invalid Sentence");
				return;
			}
		}
		
		for(i=0;i<sent.length();i++){
			j=0;
			flag1=0;
			while(j<sent.length()){
				if(s[i]==s[j] && j!=i)
				{
				//	x[i]=s[j];
					flag1=1;
					break;
				}
				j++;
			}
			if(flag1==0){
				flag2=1;
				cnt++;
				if(cnt==1)
				System.out.println("Unique characters:");
				System.out.println(s[i]);
			}
		}
		if(flag2==0){
			System.out.println("No unique characters");
		}
	}
}