import java.util.*;
public class HighestMarkPerSem{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		int n,i,j,temp;
		System.out.println("Enter no of semester:");
		n=sc.nextInt();
		int max[]=new int[n];
		int sub[]=new int[n];
		for(i=0;i<n;i++){
			System.out.println("Enter no of subjects in "+(i+1)+" semester:");
			sub[i]=sc.nextInt();
		}
		for(i=0;i<n;i++){
			ArrayList<Integer> marks=new ArrayList<Integer>();
			System.out.println("Marks obtained in semester "+(i+1)+":");
			for(j=0;j<sub[i];j++){
				temp=sc.nextInt();
				if(temp<0 || temp>100){
					System.out.println("You have entered invalid mark.");
					return;
				} 
				marks.add(temp);
			}
			//System.out.println(max[i]);
			max[i]=Collections.max(marks);
		}
		for(i=0;i<n;i++){
			System.out.println("Maximum mark in "+(i+1)+" semester:"+max[i]);
		}
	}
}