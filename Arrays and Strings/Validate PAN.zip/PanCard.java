import java.util.*;
public class PanCard{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		String pan=null;
		int i,flag=0;
		System.out.println("Enter the PAN no:");
		pan=sc.nextLine();
		char[] p=pan.toCharArray();
		for(i=0;i<5;i++){
			if(p[i]<65 || p[i]>90){
				flag=1;
				System.out.println("Invalid PAN no");
				return;
			}
		}
		/*if(flag==1){
			
			return;
		}*/
			for(i=5;i<9;i++){
				if(p[i]<48 || p[i]>57){
					System.out.println("Invalid PAN no");
					return;
				}
			}
			if(p[9]<65 || p[9]>90){
				System.out.println("Invalid PAN no");
				return;
			}
			System.out.println("Valid PAN no");
	}
}