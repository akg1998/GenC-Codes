import java.util.*;
public class Count{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		int a[]=new int[20];
		int n,pass = 0,fail = 0,flag = 0;
		System.out.println("Enter the no of subjects:");
		n=sc.nextInt();
		if(n==0 || n<0){
			System.out.println("Invalid input range");
			return;
		}
		for(int i=0;i<n;i++){
			a[i]=sc.nextInt();
		}
		for(int i=0;i<n;i++){
			if(a[i]<50){
				flag=1;
				break;
			}
		}
		if(flag==0){
			System.out.println("Ram passed in all subjects");
			return;
		}
		else{
		flag=0;
		}
		for(int i=0;i<n;i++){
			if(a[i]>50){
				flag=1;
				break;
			}
		}
		if(flag==0){
			System.out.println("Ram failed in all subjects");
			return;
		}
		else{
			flag=0;
		}
		for(int i=0;i<n;i++){
			if(a[i]<50){
				fail++;
			}
			else{
				pass++;
			}
		}
		System.out.println("Ram passed in "+pass+" subjects and failed in "+fail+" subjects");
	}
}