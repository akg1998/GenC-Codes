import java.util.*;
public class CompatibleArrays{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size for First array:");
		int n,flag=0;
		n=sc.nextInt();
		if(n<=0){
			System.out.println("Invalid array size");
			return;
		}
		int a[]=new int[n];
		int m;
		System.out.println("Enter the elements for First array:");
		for(int i=0;i<n;i++){
			a[i]=sc.nextInt();
		}
		System.out.println("Enter the size for Second array:");
		m=sc.nextInt();
		if(m<=0){
			System.out.println("Invalid array size");
			return;
		}
		int b[]=new int[m];
		System.out.println("Enter the elements for Second array:");
		for(int i=0;i<m;i++)
		{
			b[i]=sc.nextInt();
		}
		if(n==m){
			for(int i=0;i<n;i++){
				if(a[i]<b[i]){
					flag=1;
					break;
				}
			}
			if(flag==1)
				System.out.println("Arrays are Not Compatible");
			else
				System.out.println("Arrays are Compatible");
		}
		else{
			System.out.println("Arrays are Not Compatible");
		}
	
	}
}