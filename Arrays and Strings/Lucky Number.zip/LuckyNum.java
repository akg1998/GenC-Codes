import java.util.*;
public class LuckyNum{
	public static void main(String[] args){
 		Scanner sc=new Scanner(System.in);
		int no,sum=0,cnt=0;
		System.out.println("Enter the car no:");
		no=sc.nextInt();
		int temp,x;
		temp=no;
		if(no<0 || no==0)
		{
			System.out.println(no+" is not a valid car number");
			return;
		}
		while(temp!=0){
			x=temp%10;
			sum=sum+x;
			temp=temp/10;
			cnt++;
		}
		if(cnt!=4){
			System.out.println(no+" is not a valid car number");
			return;
		}
		if(sum%3==0 || sum%5==0 || sum%7==0){
			System.out.println("Lucky Number");
		}
		else
		{
			System.out.println("Sorry its not my lucky number");
		}
		
	}
}