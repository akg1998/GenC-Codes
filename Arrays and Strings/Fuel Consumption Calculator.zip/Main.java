import java.util.*;
class Main{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        float no_of_liters,distance;
        System.out.println("Enter the no of liters to fill the tank ");
        no_of_liters=sc.nextFloat();
        /*System.out.println("Enter the distance covered ");
        distance=sc.nextFloat();*/
        if(no_of_liters<=0.0)
        {
            
            System.out.println((int)no_of_liters+" is an Invalid Input");
            return;
        }
        System.out.println("Enter the distance covered");
        distance=sc.nextFloat();
        if(distance<=0.0)
        {
            System.out.println((int)distance+" is an Invalid Input");
            return;
        }
        
        float cost;
        cost=(float)(no_of_liters/distance)*100;
        System.out.println("Liters/100KM ");
        System.out.printf("%.2f",cost);
        System.out.println();
        float In_Miles,In_Gallons;
        In_Miles=(float)(distance*0.6214);
        In_Gallons=(float)(no_of_liters*0.2642);
        float miles_gallons;
        miles_gallons=In_Miles/In_Gallons;
        System.out.println("Miles/Gallons ");
        System.out.printf("%.2f",miles_gallons);
        System.out.println();
        }
}