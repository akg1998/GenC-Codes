import java.util.*;
public class Main{
    public static void main (String[] args) {
     Scanner sc=new Scanner(System.in);
     
     // Fill the code here
    Map<String,Integer> map=new LinkedHashMap<>();
    String objects;
    int price,i;
    int discount=0;
    double x;
    int discounted_price=0;
    int n;
    n=sc.nextInt();
    for(i=0;i<n;i++)
    {
        objects=sc.next();
        String[] a=objects.split(",");
        price=Integer.parseInt(a[1]);
        discount=Integer.parseInt(a[2]);
        x=discount*0.01;
        discounted_price=(int)(price*x);
        map.put(a[0],discounted_price);
    }
    int min=Collections.min(map.values());
    Set<String> keySet=map.keySet();
    for(String key: keySet){
        if(map.get(key)==min)
        {
            System.out.println(key);
        }
        }
        
    /*map.forEach((k,v)->{
        if(v==min){
            System.out.println(k);
        }
    });*/
    }
}