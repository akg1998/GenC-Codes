import java.util.*;
public class BikeRace{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		int distance,m1=1,m2=1,temp,n,reverse=0;
		System.out.println("Enter the distance travelled");
		distance=sc.nextInt();
		if(distance<0){
			System.out.println("Invalid Input");
		}
		else{
			String no=Integer.toString(distance);
			int a[]=new int[no.length()];
			int i=0;
			temp=distance;
			while(temp!=0 && i<no.length()){
				n=temp%10;
				a[i]=n;
				i++;
				temp=temp/10;
			}
		//	System.out.println(no.length());
			for(i=0;i<no.length();i++){
				if(i%2==0){
					m1=m1*a[i];
				//	System.out.println(a[i]);
				}
				else if(i%2==1){
					m2=m2*a[i];
					//System.out.println(a[i]);
				}
			}
			if(m1>m2 || distance==0){
				System.out.println("Your bonus points is "+m1);
			}
			else if(m1<m2){
				System.out.println("Your bonus points is "+m2);
			}
			else if(m1==m2){
				System.out.println("Your bonus points is "+(m2*2));
			}
		}
	}
}