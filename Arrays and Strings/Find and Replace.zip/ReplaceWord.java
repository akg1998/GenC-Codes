import java.util.*;
public class ReplaceWord{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String input=null;
		String search=null;
		String replace=null;
		System.out.println("Enter the string:");
		input=sc.nextLine();
		System.out.println("Enter the word to be searched:");
		search=sc.nextLine();
		System.out.println("Enter the word to be replaced:");
		replace=sc.nextLine();
		if(input.contains(search)){
			input=input.replace(search, replace);
			System.out.println(input);
		}
		else{
			System.out.println("The word "+search+" not found");
		}
	}
}