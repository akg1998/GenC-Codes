import java.util.*;
public class Palindrome{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		int no,reverse=0,temp,n;
		no=sc.nextInt();
		if(no<0){
			System.out.println("Invalid Input");
			return;
		}
		temp=no;
		while(temp!=0){
			n=temp%10;
			reverse=reverse*10+n;
			temp=temp/10;
		}
		if(no==reverse){
			System.out.println("Palindrome");
		}
		else if(no!=reverse)
		{
			System.out.println("Not a Palindrome");
		}
	}
}