import java.util.*;
public class CinemaTicket{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		int no_ticket;
		double total_cost = 0;
		char ref,cc,circle;
		System.out.println("Enter the no of ticket:");
		no_ticket=sc.nextInt();
		if(no_ticket<5 || no_ticket>40){
			System.out.println("Minimum of 5 and Maximum of 40 Tickets");
			return;
		}
		System.out.println("Do you want refreshment:");
		ref=sc.next().charAt(0);
		System.out.println("Do you have coupon code:");
		cc=sc.next().charAt(0);
		System.out.println("Enter the circle:");
		circle=sc.next().charAt(0);
		if(circle!='k' && circle!='q'){
			System.out.println("Invalid Input");
			return;
		}
		else{
			if(no_ticket>20){
				if(circle=='k'){
					total_cost=no_ticket*75;
					total_cost=total_cost-(total_cost*0.1);
				}
				else if(circle=='q'){
					total_cost=no_ticket*150;
					total_cost=total_cost-(total_cost*0.1);
				}
				if(cc=='y')
					total_cost=total_cost-(total_cost*0.02);
				if(ref=='y')
					total_cost=total_cost+(no_ticket*50);
			}
			else if(no_ticket<=20){
				if(circle=='k'){
					total_cost=no_ticket*75;
				}
				else if(circle=='q'){
					total_cost=no_ticket*150;
				}
				if(cc=='y')
					total_cost=total_cost-(total_cost*0.02);
				if(ref=='y')
					total_cost=total_cost+(no_ticket*50);
			}
		}
		System.out.printf("Ticket cost:%.2f",total_cost);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*if(no_ticket>=5 && no_ticket<=40){
			System.out.println("Do you want refreshment:");
			ref=sc.next().charAt(0);
			System.out.println("Do you have coupon code:");
			cc=sc.next().charAt(0);
			System.out.println("Enter the circle:");
			circle=sc.next().charAt(0);
			if(circle=='k'){
				if(no_ticket>20){
					if(ref=='y'){
						if(cc=='y'){
							total_cost=75*no_ticket;
							total_cost=total_cost-(total_cost*0.1);
							total_cost=total_cost-(total_cost*0.02);
							total_cost=total_cost+(no_ticket*50);
							System.out.printf("Ticket cost:%.2f\n",total_cost);
						}
						else
						{
							total_cost=75*no_ticket;
							total_cost=total_cost-(total_cost*0.1);
							total_cost=total_cost+(no_ticket*50);
							System.out.printf("Ticket cost:%.2f\n",total_cost);
						}
					}
					else
					{
						if(cc=='y'){
							total_cost=75*no_ticket;
							total_cost=total_cost-(total_cost*0.1);
							total_cost=total_cost-(total_cost*0.02);
							System.out.printf("Ticket cost:%.2f\n",total_cost);
						}
						else{
							total_cost=75*no_ticket;
							total_cost=total_cost-(total_cost*0.1);
							System.out.printf("Ticket cost:%.2f\n",total_cost);
						}
					}
				}
			}
			else if(circle=='q'){
				if(no_ticket>20){
					if(ref=='y'){
						if(cc=='y'){
							total_cost=150*no_ticket;
							total_cost=total_cost-(total_cost*0.1);
							total_cost=total_cost-(total_cost*0.02);
							total_cost=total_cost+(no_ticket*50);
							System.out.printf("Ticket cost:%.2f\n",total_cost);
						}
						else
						{
							total_cost=150*no_ticket;
							total_cost=total_cost-(total_cost*0.1);
							total_cost=total_cost+(no_ticket*50);
							System.out.printf("Ticket cost:%.2f\n",total_cost);
						}
					}
					else
					{
						if(cc=='y'){
							total_cost=150*no_ticket;
							total_cost=total_cost-(total_cost*0.1);
							total_cost=total_cost-(total_cost*0.02);
							System.out.printf("Ticket cost:%.2f\n",total_cost);
						}
						else{
							total_cost=150*no_ticket;
							total_cost=total_cost-(total_cost*0.1);
							System.out.printf("Ticket cost:%.2f\n",total_cost);
						}
					}
				}
			}
			else
			{
				System.out.println("Invalid Input");
			}
			
		}
		else{
			System.out.println("Minimum of 5 and Maximum of 40 Tickets");
		}
	}*/
		
	}
}