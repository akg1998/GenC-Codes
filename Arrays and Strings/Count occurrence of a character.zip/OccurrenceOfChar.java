import java.util.*;
public class OccurrenceOfChar{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String input=null;
		System.out.println("Enter a word:");
		input=sc.nextLine();
		if(!(input.matches("^[a-zA-Z]*$"))){
			System.out.println("Not a valid string");
			return;
		}
		System.out.println("Enter the character:");
		char c;
		int cnt=0;
		char[] x=input.toCharArray();
		c=sc.next().charAt(0);
		if((c<65 || c>90)&&(c<97 || c>122)){
			System.out.println("Given character is not an alphabet");
			return;
		}
		String find=null;
		/*find=sc.nextLine();
		if(!(find.matches("[a-zA-Z]"))){
			System.out.println("Given character is not an alphabet");
			return;
		}*/
		for(int i=0;i<input.length();i++){
			if(x[i]==c)
				cnt++;
		}
		/*if(input.contains(find)){
			cnt=input.
		}*/
		if(cnt>0){
		System.out.println("No of '"+c+"' present in the given word is "+cnt);
		}
		else{
			System.out.println("The given character '"+c+"' not present in the given word.");
		}
		find=null;
	}
}