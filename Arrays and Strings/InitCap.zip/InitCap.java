import java.util.*;

public class InitCap{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the String:");
        String input=sc.nextLine();
        StringBuilder output = new StringBuilder(input.length());
                                String words[] = input.split("\\ "); 
                                for (int i = 0; i < words.length; i++)
                                {                                              
                                                output.append(Character.toUpperCase(words[i].charAt(0))).append(words[i].substring(1)).append(" ");
                                                
                                }
                                int flag=0;
                                for(int i=0;i<input.length();i++){
                                    if(input.charAt(i)!=output.charAt(i)){
                                        flag=1;
                                        break;
                                    }
                                }
                                if(flag==0){
                                    System.out.println("First character of each word is already in uppercase");
                                    return;
                                }
                                System.out.println(output);
                //            System.out.println(input);
                                
    }
}
