import java.util.*;
public class Course{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		int n,flag=0,i;
		String[] str=new String[20];
		String search=null;
		System.out.println("Enter no of course:");
		n=sc.nextInt();
		sc.nextLine();
		if(n==0 || n<0)
			System.out.println("Invalid Range");
		else
		{
			System.out.println("Enter course names:");
			for(i=0;i<n;i++)
			{
				str[i]=sc.nextLine();
			}
			System.out.println("Enter the course to be searched:");
			search=sc.nextLine();
			for(i=0;i<n;i++){
				if(search.equals(str[i]))
				{
					System.out.println(search+" course is available");
					flag=1;
					break;
				}
			}
			if(flag==0)
			{
				System.out.println(search+" course is not available");
			}
		}
	}
}