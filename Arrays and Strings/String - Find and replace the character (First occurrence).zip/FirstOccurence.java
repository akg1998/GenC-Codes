import java.util.*;
public class FirstOccurence{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		String inp=null;
		String output=null;
		char s,r;
		System.out.println("Enter the string:");
		inp=sc.nextLine();
		System.out.println("Enter the character to be searched:");
		s=sc.next().charAt(0);
		System.out.println("Enter the character to replace:");
		r=sc.next().charAt(0);
		char[] inp1=inp.toCharArray();
		int flag=0,i,pos = 0;
		for(i=0;i<inp1.length;i++){
			if(inp1[i]==s){
				flag=1;
				pos=i;
				break;
			}
		}
		if(flag==1){
			inp1[pos]=r;
			output=inp1.toString();
			System.out.println(inp1);
		}
		else if(flag==0){
			System.out.println("character not found");
		}
	}
}