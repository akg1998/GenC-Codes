import java.util.*;
public class PrimeNumbers{
	public static void main(String[] args){
		int temp,no1,no2,flag=0,j;
		Scanner sc=new Scanner(System.in);
		no1=sc.nextInt();
		no2=sc.nextInt();
		if(no1>no2 || no1<=0 || no2<=0 || no1==no2){
			System.out.println("Provide valid input");
			return;
		}
		else
		{
			for(int i=no1;i<=no2;i++){
				if(i==1)
					continue;
				else
				{
					j=2;
					while(j<i){
						if(i%j==0){
							flag=1;
							break;
						}
						j++;
					}
					if(flag==0)
					{
						System.out.print(i+" ");
					}
					flag=0;
				}
				
				
			}
		}
	}
}