import java.util.*;
public class Numerology{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Map<Character,Integer> input=new HashMap<Character,Integer>();
		input.put('A', 1);
		input.put('B', 2);
		input.put('C', 3);
		input.put('D', 4);
		input.put('E', 5);
		input.put('F', 8);
		input.put('G', 3);
		input.put('H', 5);
		input.put('I', 1);
		input.put('J', 1);
		input.put('K', 2);
		input.put('L', 3);
		input.put('M', 4);
		input.put('N', 5);
		input.put('O', 7);
		input.put('P', 8);
		input.put('Q', 1);
		input.put('R', 2);
		input.put('S', 3);
		input.put('T', 4);
		input.put('U', 6);
		input.put('V', 6);
		input.put('W', 6);
		input.put('X', 5);
		input.put('Y', 1);
		input.put('Z', 7);
		String name=null;
		System.out.println("Enter your name:");
		name=sc.nextLine();
		if(!name.matches("^[A-Z]*$")){
			System.out.println("Invalid Name");
		}
		else{
			char s[]=name.toCharArray();
			int sum=0,i,temp;
			for(i=0;i<s.length;i++){
				temp=input.get(s[i]);
				sum=sum+temp;
			}
			System.out.println("Your numerology no is:"+sum);
		}
		sc.close();
		
	}
}