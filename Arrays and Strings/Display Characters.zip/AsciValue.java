import java.util.*;
public class AsciValue{
	public static void main(String[] args){
		int a[]=new int[4];
		int i;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the digits:");
		for(i=0;i<4;i++){
			a[i]=sc.nextInt();
		}
		for(i=0;i<4;i++){
			System.out.println(a[i]+"-"+(char)a[i]);
		}
	}
}