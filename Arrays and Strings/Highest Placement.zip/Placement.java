import java.util.*;
public class Placement{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		int cse,ece,mech;
		System.out.println("Enter the no of students placed in CSE:");
		cse=sc.nextInt();
		System.out.println("Enter the no of students placed in ECE:");
		ece=sc.nextInt();
		System.out.println("Enter the no of students placed in MECH:");
		mech=sc.nextInt();
		int max=cse;
		if(true){
		if(cse<0 || ece<0 || mech<0 ){
			System.out.println("Input is Invalid");
			System.exit(0);
		}
		else if((cse==0 && ece==0 && mech==0)||(max==cse && max==ece && max==mech)){
			System.out.println("None of the department has got the highest placement");
			System.exit(0);
		}
		}
		if(true){
			System.out.println("Highest Placement");
		if(cse>mech && cse>mech){
			System.out.println("CSE");
			if(mech==cse){
				System.out.println("MECH");
			}
			if(cse==ece){
				System.out.println("ECE");
			}
		}
		else if(ece>cse && ece>mech){
			System.out.println("ECE");
			if(ece==cse){
				System.out.println("CSE");
			}
			if(mech==ece){
				System.out.println("MECH");
			}
		}
		else if(mech>ece && mech>cse){
			System.out.println("MECH");
			if(mech==cse){
				System.out.println("CSE");
			}
			if(mech==ece){
				System.out.println("ECE");
			}
			}
		}
	}
}