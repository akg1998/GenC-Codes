import java.util.*;
public class Test{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter total no.of employees:");
		int n;
		n=sc.nextInt();
		if(n<2){
			System.out.println("Please enter a valid employee count");
			return;
		}
		int a[]=new int[n];
		System.out.println("Enter the age for "+n+" employees:");
		for(int i=0;i<n;i++){
			a[i]=sc.nextInt();
			if(a[i]<28 || a[i]>40){
				System.out.println("Invalid age encountered!");
				return;
			}
		}
		int sum=0;
		double average;
		for(int i=0;i<n;i++){
			sum+=a[i];
		}
		average=(double)sum/n;
		System.out.printf("The average age is %.2f",average);
	}
}