import java.util.*;
public class Authority{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Inmate's name:");
		String name=null;
		String result=null;
		name=sc.nextLine();
		System.out.println("Inmate's father's name:");
		String final1=null;
		final1=sc.nextLine();
		if(!(name.matches("[A-Za-z ]*")&&(final1.matches("[A-Za-z ]*"))))
		{
			System.out.println("Invalid name");
			return;
		}
		else{
			result=name.toUpperCase()+" "+final1.toUpperCase();
			System.out.println(result);
		}
	}
}