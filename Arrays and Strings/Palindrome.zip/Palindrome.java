import java.util.*;
public class Palindrome{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		int flag=0,i,j;
		String input=null;
		System.out.println("Enter the word:");
		input=sc.nextLine();
		char word[]=input.toCharArray();
		for(i=0;i<word.length;i++){
			if((word[i]<65||word[i]>90) && (word[i]<97 || word[i]>122)){
				System.out.println("Invalid Input");
				return;
			}
		}
		word=input.toLowerCase().toCharArray();
		for(i=0,j=word.length-1;i<j;i++,j--)
		{
			//System.out.println(word[i]+" "+word[j]);
			if(word[i]!=word[j]){
				flag=1;
				break;
			}
		}
		if(flag==1){
			System.out.println(input+" is not a Palindrome");
		}
		else
		{
			System.out.println(input+" is a Palindrome");
		}
			
	}
}