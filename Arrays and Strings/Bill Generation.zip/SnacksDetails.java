import java.util.*;
public class SnacksDetails{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		int p,pu,cd,tp;
		System.out.println("Enter the no of pizzas bought:");
		p=sc.nextInt();
		System.out.println("Enter the no of puffs bought:");
		pu=sc.nextInt();
		System.out.println("Enter the no of cool drinks bought");
		cd=sc.nextInt();
		tp=p*100+pu*20+cd*10;
		System.out.println("Bill Details");
		System.out.println("No of pizzas:"+p);
		System.out.println("No of puffs:"+pu);
		System.out.println("No of cooldrinks:"+cd);
		System.out.println("Total price="+tp);
		System.out.println("ENJOY THE SHOW!!!");
	}
}