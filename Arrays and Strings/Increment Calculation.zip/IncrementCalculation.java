import java.util.*;
public class IncrementCalculation{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		int salary;
		double rating;
		System.out.println("Enter the salary");
		salary=sc.nextInt();
		System.out.println("Enter the Performance appraisal rating");
		rating=sc.nextDouble();
		if(salary==0 || salary<0  || rating>5 || rating<0){
			System.out.println("Invalid Input");
			return;
		}
		else{
			if(rating>=1 && rating <=3){
				salary=salary+(salary*10/100);
			}
			else if(rating>=3.1 && rating<=4)
			{
				salary=salary+(salary*25/100);
			}
			else if(rating>=4.1 && rating<=5){
				salary=salary+(salary*30/100);
			}
			System.out.println(salary);
		}
	}
}