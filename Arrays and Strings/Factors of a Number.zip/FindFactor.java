import java.util.*;
public class FindFactor{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		int no;
		no=sc.nextInt();
		if(no==0){
			System.out.println("No Factors");
		}
		else{
			if(no<0) no=-no;
			for(int i=1;i<=no/2;i++){
				if(no%i==0){
					System.out.print(i+", ");
				}
			}
			System.out.print(no);
		}
	}
}