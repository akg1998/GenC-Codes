import java.util.*;
public class Count{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		int no;
		System.out.println("Enter the standard:");
		no=sc.nextInt();
		int i,temp,result,sum;
		if(no<0 || no>12 || no==0){
			System.out.println("Invalid Standard");
		}
		else
		{
			i=1;
			sum=0;
			while(i<no){
				temp=i*i+sum;
				sum=temp;
				i++;
			}
			result=no*no+sum;
			System.out.println("Nila gets "+result+" pencils");
		}
		
	}
}