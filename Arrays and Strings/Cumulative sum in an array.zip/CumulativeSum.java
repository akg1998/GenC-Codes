import java.util.*;
public class CumulativeSum{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n,sum=0,i;
		System.out.println("Enter number of elements");
		n=sc.nextInt();
		int a[]=new int[20];
		if(n<=0){
			System.out.println("Invalid Range");
			return;
		}
		else{
			System.out.println("Enter the elements");
			for(i=0;i<n;i++){
				a[i]=sc.nextInt();
			}
			//System.out.print(a[0]+" ");
			for(i=0;i<n;i++){
				sum=sum+a[i];
				System.out.print(sum+" ");
			}
		}
	}
}