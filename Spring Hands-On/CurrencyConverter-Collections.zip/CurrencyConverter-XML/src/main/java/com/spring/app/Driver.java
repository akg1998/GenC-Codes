package com.spring.app;

import java.util.HashMap;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Driver {

	public static void main(String[] args) {

		/*@SuppressWarnings("resource")
		ApplicationContext apc = new ClassPathXmlApplicationContext("beans.xml");
		CurrencyConverter c = (CurrencyConverter) apc.getBean("currency");
		int num = c.getTotalCurrencyValue("7Dollar");
		System.out.println(num);*/
	}

}
