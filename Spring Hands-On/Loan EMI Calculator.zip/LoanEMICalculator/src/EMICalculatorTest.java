import static org.junit.Assert.*;
import java.util.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

public class EMICalculatorTest {

        private EMICalculator emi=new EMICalculator();
        private double amount;
//Write JUNIT Test Code
    @Test
    public void calculateEMI(){
        amount=emi.calculateEMI(0," ",0);
        assertEquals(0.0,amount,0.001);
        amount=emi.calculateEMI(10000,"Housing Loan",20);
        assertEquals(42.1707,amount,0.001);
        amount=emi.calculateEMI(10000,"Vehicle Loan",20);
        assertEquals(42.1285,amount,0.001);
        amount=emi.calculateEMI(10000,"Personal Loan",20);
        assertEquals(42.0864,amount,0.001);
    }
    
}
