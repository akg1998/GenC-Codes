package com.spring.ui;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.app.Address;
import com.spring.app.AddressBook;

public class Driver {

	public static AddressBook loadAddressBook() {
		ApplicationContext apc = new ClassPathXmlApplicationContext("applicationContext.xml");
		AddressBook ab=(AddressBook)apc.getBean("addBook");
		return ab;
	}

	public static void main(String[] args) {
		// invoke the loadAddressBook() method from main retrieve the
		// AddressBook object, get the details from the user set the values and
		// display the values
		Scanner sc=new Scanner(System.in);
		AddressBook a=Driver.loadAddressBook();
		Address b=a.getTempAddress();
		System.out.println("Enter the temporary address");
		System.out.println("Enter the house name");
		b.setHouseName(sc.nextLine());
		System.out.println("Enter the Street");
		b.setStreet(sc.nextLine());
		System.out.println("Enter the city");
		b.setCity(sc.nextLine());
		System.out.println("Enter the state");
		b.setState(sc.nextLine());
		System.out.println("Enter the phone number");
		a.setPhoneNumber(sc.nextLine());
		System.out.println("Temporary address");
		System.out.println("House name:"+b.getHouseName());
		System.out.println("Street:"+b.getStreet());
		System.out.println("City:"+b.getCity());
		System.out.println("State:"+b.getState());
		System.out.println("Phone number:"+a.getPhoneNumber());
	}

}
