package com.spring.app;


public class Driver {
	
public static void main(String[] args)
{
	/*ApplicationContext apc=new ClassPathXmlApplicationContext("applicationContext.xml");
	MemberShip m=(MemberShip) apc.getBean("memberShip");
	System.out.println(m);
	*/
}
}
