import static org.junit.Assert.*;
import static org.junit.Assert.fail;
import org.junit.Test;


public class EBBillTest
{
    @Test
    public void calculateBillAmount(){
        EBBill bill=new EBBill(0);
        double actual=bill.calculateBillAmount();
        assertEquals(0.0,actual,0.001);
        EBBill bill2=new EBBill(50);
        double actual2=bill2.calculateBillAmount();
        assertEquals(130.0,actual2,0.001);
        EBBill bill3=new EBBill(100);
        double actual3=bill3.calculateBillAmount();
        assertEquals(292.5,actual3,0.001);
        EBBill bill4=new EBBill(200);
        double actual4=bill4.calculateBillAmount();
        assertEquals(818.5,actual4,0.001);
        EBBill bill5=new EBBill(1000);
        double actual5=bill5.calculateBillAmount();
        assertEquals(7018.5,actual5,0.001);
        EBBill bill6=new EBBill(5000);
        double actual6=bill6.calculateBillAmount();
        assertEquals(47018.5,actual6,0.001);
    }
    
}