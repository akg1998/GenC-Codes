import org.junit.Test;
import static org.junit.Assert.fail;
import static org.junit.Assert.*;

public class ProductTest {

 //Write the code for test methods
        @Test
        public void deleteproduct(){
            Product pro=new Product();
            ProductDAO l=new ProductDAO();
            pro.setProductId("a");
            pro.setProductName("c");
            pro.setPrice(123.0);
            String u=pro.getProductId();
            String p=pro.getProductName();
            double a=pro.getPrice();
             boolean test2=l.addProduct(pro);
             assertTrue(test2);
            assertFalse(l.deleteProduct(null));
            boolean test=l.deleteProduct(pro);
            assertTrue(test);
            assertFalse(l.addProduct(null));
            
        }
}
