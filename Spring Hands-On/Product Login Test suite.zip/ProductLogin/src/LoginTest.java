import org.junit.Test;
import static org.junit.Assert.fail;
import static org.junit.Assert.*;


public class LoginTest {

      //Write the code for adding and deleting Login data
        @Test
        public void methoddeleteLogin(){
            Login login=new Login("a","b");
            LoginDAO l=new LoginDAO();
            login.setUserName("a");
            login.setPassword("c");
            String u=login.getUserName();
            String p=login.getPassword();
            assertFalse(l.deleteLogin(null));
            boolean test2=l.addLogin(login);
            assertTrue(test2);
            boolean test=l.deleteLogin(login);
            assertFalse(l.addLogin(null));
            assertTrue(test);
            
        }
    

}

