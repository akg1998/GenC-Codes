import org.junit.Assert.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class CustomerTest {
	//Write the code for testing assertion using JUNIT
	private Customer c=new Customer("000000000000","abv","bc","cs",9876543,"qwerty");
    @Test
    public void check(){
         assertTrue(c.isValidAadharNo("900000000000"));
         assertNotEquals(c.getFirstName(),c.getLastName());
         assertNotNull(c.getEmailId());
    }
}
