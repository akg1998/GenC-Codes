package com.service;

import org.springframework.stereotype.Service;

import com.model.Ticket;;
@Service
public class TicketService {
	
	
	public double calculateTotalCost(Ticket ticket)
	{
		String type=ticket.getCircleType();
		double ans=0.0;
		if(type.equals("Queen")){
			ans=ticket.getNoOfTickets()*(double)250;
		}
		else
		{
			ans=ticket.getNoOfTickets()*(double)150;
		}
		return ans;
		
	}

}
	 	  	    	    	     	      	 	

