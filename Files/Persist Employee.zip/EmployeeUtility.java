import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class EmployeeUtility {
    
    	public boolean addEmployee(String fileName,ArrayList<Employee> employeeList){
			FileOutputStream file;
			ObjectOutputStream out;
			try {
				 file=new FileOutputStream(fileName);
				out=new ObjectOutputStream(file);
				out.writeObject(employeeList);
				out.close();
				file.close();
			} catch (IOException e) {
				return false;
			}
			return true;	
		}
		public Employee viewEmployeeById(String fileName,int employeeId){
			FileInputStream file;
			Employee emp=null;
			ArrayList<Employee> list=null;
			try {
				file = new FileInputStream(fileName);
				ObjectInputStream in=new ObjectInputStream(file);
				list=(ArrayList)in.readObject();
				for(Employee e: list){
					if(e.getEmployeeId()==employeeId){
						emp=e;
						break;
					}
				}
				in.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return emp;
		}
    
}