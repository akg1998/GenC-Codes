//import necessary packages
import java.io.*;
@SuppressWarnings("unchecked")//Do not delete this line
public class FileManager 
 {
    
    static public File createFile()
    {
        File f = new File("visitors.txt");
        try{
            boolean c = f.createNewFile();
        }
        catch(IOException e){
            e.printStackTrace();
        }
        return f;//change the return type as per the requirement    
    }
    static public void writeFile(File f, String record)
                {
                    try{
                    FileWriter out = new FileWriter(f,true); 
            out.write(record); 
            out.close();
                    }
                    catch (IOException e) { 
            e.printStackTrace();
        } 
                } 
                static public String[] readFile(File f)
                {   
                    try{
                                BufferedReader bf = new BufferedReader(new FileReader(f));
                                String records = "";
                                records = bf.readLine();
                                String [] recordArray = records.split(";");
                                return recordArray;
                    }
                    catch(IOException e){
                                e.printStackTrace();
                   }
                    return null;//change the return type as per the requirement  
                }
}

