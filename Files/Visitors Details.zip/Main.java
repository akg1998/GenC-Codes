//import necessary packages
import java.util.*;
import java.io.*;
@SuppressWarnings("unchecked")//Do not delete this line
public class Main{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        File f = FileManager.createFile();
        String[] str;
        String s = "";
        String n="",pn="",e="",yn="";
                    while(true){
            System.out.println("Enter Name");
            n = sc.nextLine();
            System.out.println("Enter Phone Number");
            pn = sc.nextLine();
            System.out.println("Enter Email");
            e = sc.nextLine();
            s = n+","+pn+","+e+";";
           FileManager.writeFile(f,s);
            System.out.println("Do you want to enter another record(yes/no)");
            yn = sc.nextLine();
            if(yn.equals("no"))
                break;
                    }
                    String [] strr = FileManager.readFile(f);
                    for(String sss:strr){
                        System.out.println(sss);
                    }
                }
}
