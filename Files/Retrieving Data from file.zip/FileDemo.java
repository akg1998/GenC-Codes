import java.io.*;
import java.util.*;
public class FileDemo
{
    public static void main(String[] args) throws IOException
    {
        File f=new File("log.txt");
        BufferedReader br=new BufferedReader(new FileReader(f));
        String st=br.readLine();
        System.out.println(st);
    }
}