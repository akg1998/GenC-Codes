import java.io.*;
public class FileDemo{
    public static void main(String[] args){
        String[] words=null;
        int max=0;
        String str = "";
        try{
            FileReader fr = new FileReader("log.txt");
            BufferedReader br = new BufferedReader(fr); 
            String s;
            while((s=br.readLine())!=null){
                words=s.split(" "); 
                for(String ss : words){
                   if(ss.length()>max){
                        max = ss.length();
                        str = ss;
                    }
                }
            }
            fr.close();
            System.out.println(str);
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
    }
}

