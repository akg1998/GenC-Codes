import java.io.*;
public class FileDemo{
    public static void main(String[] args)
    {
         String[] words=null;
         int wc=0;
         try{
             FileReader fr = new FileReader("log.txt");
            BufferedReader br = new BufferedReader(fr); 
            String s;
            while((s=br.readLine())!=null){
                words=s.split(" "); 
                for(String ss : words){
                   if((ss.toLowerCase()).equals("knowledge"))
                                   wc++;
                }
            }
            fr.close();
            System.out.println(wc);
         }
         catch(IOException ex){
                                ex.printStackTrace();
                }
    }
}
