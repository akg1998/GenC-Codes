package com.ui;
import com.utility.*;
import java.util.*;

public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		//Fill the UI code
		Map<Integer,String> map=new HashMap<Integer,String>();
		List<Integer> result=new ArrayList<Integer>();
		Bazaar b=new Bazaar();
		int n,i;
		int number;
		String name,search;
		System.out.println("Enter the no of Policy names you want to store");
		n=sc.nextInt();
		for(i=0;i<n;i++){
		    System.out.println("Enter the Policy ID");
		    number=sc.nextInt();
		    sc.nextLine();
		    System.out.println("Enter the Policy Name");
		    name=sc.nextLine();
		    /*map.add(number,name);
		    b.setPolicyMap(map);*/
		    b.addPolicyDetails(number,name);
		}
		map=b.getPolicyMap();
		Set<Integer> keySet=map.keySet();
		for(Integer key: keySet){
		    number=key;
		    name=map.get(key);
		    System.out.println(number+" "+name);
		}
		System.out.println("Enter the policy type to be searched");
		search=sc.next();
		    result=b.searchBasedOnPolicyType(search);
		    Collections.sort(result);
            System.out.println(result);
	}

}
