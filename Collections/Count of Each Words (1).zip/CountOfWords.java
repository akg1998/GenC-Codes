//import the necessary packages if needed
import java.util.*;
@SuppressWarnings("unchecked")//Do not delete this line
public class CountOfWords
{
	         public static void main(String[] args) {
				 Scanner sc=new Scanner(System.in);
				// System.out.println("Enter Student's Article");
				 List<String> check=new ArrayList<String>();
				 List<String> unique=new ArrayList<String>();
				 String input=null;
				 input=sc.nextLine();
				 String re=input;
				 re=re.replaceAll("[,.!?;:]"," ");
				/* re.replaceAll(".", " ");
				 re.replaceAll("!", " ");
				 re.replaceAll(";", " ");
				 re.replaceAll(":", " ");
				 re.replaceAll("?", " ");*/
				// System.out.println(re);
				 int cnt=0,i;
				 re=re.toLowerCase();
				 StringTokenizer str=new StringTokenizer(re," ");
				 while(str.hasMoreTokens()){
					 check.add(str.nextToken());
					 cnt++;
				 }
				 Collections.sort(check);
				// System.out.println(check);
				 System.out.println("Number of words "+cnt);
				 //System.out.println(check);
				 int count[]=new int[cnt];
				 String a[]=new String[cnt];
				 int x=0;
				 	for(i=0;i<cnt;i++){
					
					// System.out.println(count[i]);
					 if(!unique.contains(check.get(i)) && !check.get(i).equals("")){
						 unique.add(check.get(i));
						 x++;
					 }
				 	}
					// Collections.sort(unique);
					 System.out.println("Words with the count");
					 for(i=0;i<x;i++){
						 count[i]=Collections.frequency(check,unique.get(i));
						 
					 }
					 for(i=0;i<x;i++){
						 System.out.println(unique.get(i)+": "+count[i]);
					 }
					 
				 
			 } 
}