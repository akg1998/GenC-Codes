import java.util.ArrayList;
import java.util.List;
public class PhoneBook{
	private List<Contact> phoneBook = new ArrayList<Contact>();
	public void addContact(Contact contactObj){
		phoneBook.add(contactObj);
	}
	public List<Contact> viewAllContacts() {
		for(Contact Contacts: phoneBook){
			System.out.println("First Name: "+Contacts.getFirstName());
			System.out.println("Last Name: "+Contacts.getLastName());
			System.out.println("Phone No.: "+Contacts.getPhoneNumber());
			System.out.println("Email: "+Contacts.getEmailId());
			//phoneBook.add(Contacts);
		}
		return phoneBook;
		
	}
	public Contact viewContactGivenPhone(long phoneNumber) {
		for(Contact books: phoneBook){
			if(books.getPhoneNumber()==phoneNumber){
				return books;
			}
		}
		return null;
	}
	public boolean removeContact(long phoneNumber){
		for(Contact books: phoneBook){
			if(books.getPhoneNumber()==phoneNumber){
				phoneBook.remove(books);
				return true;
			}
		}
		return false;
		
	}
	public List<Contact> getPhoneBook() {
		return phoneBook;
	}
	public void setPhoneBook(List<Contact> phoneBook) {
		this.phoneBook = phoneBook;
	}
}