import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class Main{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int choice=0;
		List<Contact> contactList = new ArrayList<Contact>();
		Contact b=new Contact();
		PhoneBook p=new PhoneBook();
		//lib.setContactList(contactlist);
		p.setPhoneBook(contactList);
		boolean flag=true;
		while(flag){
			
		System.out.println("Menu\r\n" + 
				"\r\n" + 
				"1.Add Contact\r\n" + 
				"\r\n" + 
				"2.Display all contacts\r\n" + 
				"\r\n" + 
				"3.Search contact by phone \r\n" + 
				"\r\n" + 
				"4.Remove contact\r\n" + 
				"\r\n" + 
				"5.Exit\r\n" + 
				"\r\n" + 
				"Enter your choice:");
		choice=sc.nextInt();
		sc.nextLine();
		switch(choice){
		case 1:System.out.println("Add a Contact:");
				System.out.println("Enter the First Name:");
				b.setFirstName(sc.nextLine());
				//sc.nextLine();
				System.out.println("Enter the Last name:");
				b.setLastName(sc.nextLine());
				System.out.println("Enter the Phone No.:");
				b.setPhoneNumber(sc.nextLong());
				sc.nextLine();
				System.out.println("Enter the Email:");
				b.setEmailId(sc.nextLine());
				p.addContact(b);
				break;
		case 2: System.out.println("The contacts in the List are:");
				contactList=p.viewAllContacts();
				break;
		case 3: System.out.println("Enter the Phone number to search contact:");
				long phone=0;
				phone=sc.nextLong();
				b=p.viewContactGivenPhone(phone);
				System.out.println("First Name: "+b.getFirstName());
				System.out.println("Last Name: "+b.getLastName());
				System.out.println("Phone No.: "+b.getPhoneNumber());
				System.out.println("Email: "+b.getEmailId());
				break;
		case 4:	System.out.println("Enter the Phone number to remove :");
				long phone1=0;
				phone1=sc.nextLong();
				System.out.println("Do you want to remove the contact (Y/N): ");
				char s;
				boolean x;
				s=sc.next().charAt(0);
				if(s=='Y' || s=='y'){
					x=p.removeContact(phone1);
					if(x==true){
						System.out.println("The contact is successfully deleted.");
					}
				}
				break;
		case 5:	flag=false;
				break;
		}
		}
	
	}
}