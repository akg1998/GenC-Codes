//import the necessary packages if needed
import java.util.*;
@SuppressWarnings("unchecked")//Do not delete this line
public class UniqueWords
{
         public static void main(String[] args) {
			 Scanner sc=new Scanner(System.in);
			 System.out.println("Enter Student's Article");
			 List<String> check=new ArrayList<String>();
			 List<String> unique=new ArrayList<String>();
			 String input=null;
			 input=sc.nextLine();
			 String re=input;
			 re=re.replaceAll("[,.!?;:]"," ");
			/* re.replaceAll(".", " ");
			 re.replaceAll("!", " ");
			 re.replaceAll(";", " ");
			 re.replaceAll(":", " ");
			 re.replaceAll("?", " ");*/
			// System.out.println(re);
			 int cnt=0,i;
			 re=re.toLowerCase();
			 StringTokenizer str=new StringTokenizer(re," ");
			 while(str.hasMoreTokens()){
				 check.add(str.nextToken());
				 cnt++;
			 }
			 Collections.sort(check);
			// System.out.println(check);
			 System.out.println("Number of words "+cnt);
			 //System.out.println(check);
			 int count=0;
			 String a[]=new String[cnt];
			 int x=0;
			 	for(i=0;i<check.size();i++){
				 count=Collections.frequency(check, check.get(i));
				 if(count>=1 && !unique.contains(check.get(i)) && !check.get(i).equals("")){
					 unique.add(check.get(i));
					 x++;
				 }
			 	}
				 System.out.println("Number of unique words "+x);
				 Collections.sort(unique);
				 System.out.println("The words are");
				 for(i=0;i<unique.size();i++){
					 System.out.println((i+1)+". "+unique.get(i));
				 }	 
			 
		 }
		
}