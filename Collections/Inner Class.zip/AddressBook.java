import java.util.*;
public class AddressBook{

		private long phoneNumber;
		private Address tempAddress;
		private Address permAddress;
		public void setPhoneNumber(long phoneNumber){
			this.phoneNumber=phoneNumber;
		}
		public long getPhoneNumber(){
			return phoneNumber;
		}
		public void setTempAddress(Address tempAddress){
			this.tempAddress=tempAddress;
		}
		public Address getTempAddress(){
			return tempAddress;
		}
		public void setPermAddress(Address permAddress){
			this.permAddress=permAddress;
		}
		public Address getPermAddress(){
			return permAddress;
		}
		public class Address{
		    private String name,street,city,state;
		     
			Scanner sc=new Scanner(System.in);
			public String getName() {
				return name;
			}

			public void setName(String name) {
				this.name = name;
			}

			public String getStreet() {
				return street;
			}

			public void setStreet(String street) {
				this.street = street;
			}

			public String getCity() {
				return city;
			}

			public void setCity(String city) {
				this.city = city;
			}

			public String getState() {
				return state;
			}

			public void setState(String state) {
				this.state = state;
			}
			public void get(){
			    
			    Address a=new Address();
			    Address b=new Address();
			    System.out.println("Enter the permanent address");
		        System.out.println("Enter the house name");
		        a.name=sc.nextLine();
		        a.setName(a.name);
		        System.out.println("Enter the street");
		        a.street=sc.nextLine();
		        a.setStreet(a.street);
		        System.out.println("Enter the city");
		        a.city=sc.nextLine();
		        a.setCity(a.city);
		        System.out.println("Enter the state");
		        a.state=sc.nextLine();
		        a.setState(a.state);
		        
		        System.out.println("Enter the temporary address");
		        System.out.println("Enter the house name");
		        b.name=sc.nextLine();
		        b.setName(b.name);
		        System.out.println("Enter the street");
            	b.street=sc.nextLine();
	        	b.setStreet(b.street);
	        	System.out.println("Enter the city");
	        	b.city=sc.nextLine();
	        	b.setCity(b.city);
	        	System.out.println("Enter the state");
	        	b.state=sc.nextLine();
	            b.setState(b.state);
	            System.out.println("Enter the phone number");
		
		        System.out.println("Permanent address");
	        	System.out.println("House name:"+a.getName());
	        	System.out.println("Street:"+a.getStreet());
	        	System.out.println("City:"+a.getCity());
	        	System.out.println("State:"+a.getState());
		
	        //	inner1=b.getTempAddress();

	        	System.out.println("Temporary address");
	        	System.out.println("House name:"+b.getName());
	        	System.out.println("Street:"+b.getStreet());
	        	System.out.println("City:"+b.getCity());
	        	System.out.println("State:"+b.getState());
			}
		}

}