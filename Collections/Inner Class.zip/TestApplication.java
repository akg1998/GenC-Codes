import java.util.*;
public class TestApplication {

	public static void main(String[] args) {
	    AddressBook b=new AddressBook();
		Scanner sc=new Scanner(System.in);
		AddressBook.Address inner=b.new Address();
		AddressBook.Address inner1=b.new Address();

		/*System.out.println("Enter the permanent address");
		System.out.println("Enter the house name");
		inner.name=sc.nextLine();
		inner.setName(inner.name);
		System.out.println("Enter the street");
		inner.street=sc.nextLine();
		inner.setStreet(inner.street);
		System.out.println("Enter the city");
		inner.city=sc.nextLine();
		inner.setCity(inner.city);
		System.out.println("Enter the state");
		inner.state=sc.nextLine();
		inner.setState(inner.state);*/
		//inner.Addressprint();
		inner.get();
		b.setTempAddress(inner);
		
		
	/*	System.out.println("Enter the temporary address");
		System.out.println("Enter the house name");
		inner1.name=sc.nextLine();
		inner1.setName(inner1.name);
		System.out.println("Enter the street");
		inner1.street=sc.nextLine();
		inner1.setStreet(inner1.street);
		System.out.println("Enter the city");
		inner1.city=sc.nextLine();
		inner1.setCity(inner1.city);
		System.out.println("Enter the state");
		inner1.state=sc.nextLine();
		inner1.setState(inner1.state);
		b.setPermAddress(inner1);*/
	//	System.out.println("Enter the phone number");
		b.setPhoneNumber(sc.nextLong());
		
	//	inner.print();
		System.out.println("Phone number");
		long phone;
		phone=b.getPhoneNumber();
		System.out.println(phone);
		
		sc.close();
	    
	}
}